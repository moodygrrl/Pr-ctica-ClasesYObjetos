package ferroviaria;

public class PlantillaMain {
    public static void main(String[] args) {
        // Simulamos una estación: creamos objetos de diversos tipos:

        // dos maquinistas
        // imprimimos los datos de los dos maquinistas


        // un mecánico de cada especialidad
        // imprimimos los datos de cada mecánico


        // Un jefe de estación
        // Imprimimos los datos del jefe de estación

        // Una locomotora
        // imprimimos los datos de la locomotora



        // Creamos un tren con la locomotora que acabamos de crear

        // Añadimos 6 vagones al tren (nos dirá que el último no se puede
        System.out.println("\nAñadimos 5 vagones al tren y tratamos de añadir uno más: ");
        System.out.println("***************************");

        // Asignamos uno de los maquinistas al tren creado
        System.out.println("\n*****     Le asignamos un maquinista *****");

        // Mostramos el número de vagones del tren
        // Mostramos los datos del tren creado

        // Quitamos un vagón
        System.out.println("\n***** Quitamos un vagón *****");
        // mostramos el número de vagones del tren

        // Finalmente, contamos todos los elementos que tenemos en la estación
        System.out.println("\nMi estación se compone de");


    }
}