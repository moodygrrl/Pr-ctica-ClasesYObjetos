package ferroviaria.personal;

public class Mecánico {

    // Atributos
    private String nombre;
    private String teléfono;
    private Especialidad especialidad;

    // Constructor
    public Mecánico(String nombre, String teléfono, Especialidad especialidad) {
        this.nombre = nombre;
        this.teléfono = teléfono;
        this.especialidad = especialidad;
    }


    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTeléfono() {
        return teléfono;
    }

    public void setTeléfono(String teléfono) {
        this.teléfono = teléfono;
    }


    // toString

    // imprimirDatos()

}


