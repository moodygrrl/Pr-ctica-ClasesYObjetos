package ferroviaria.personal;

public enum Especialidad {
    FRENOS, HIDRÁULICA, ELECTRICIDAD, MOTOR
}
