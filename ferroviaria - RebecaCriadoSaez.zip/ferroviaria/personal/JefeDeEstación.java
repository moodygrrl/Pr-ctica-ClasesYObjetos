package ferroviaria.personal;

import java.time.LocalDate;

public class JefeDeEstación {

    // Atributos
    private String nombre;
    private String DNI;
    private LocalDate fechaNombramiento;

    // Constructor
    public JefeDeEstación(String nombre, String DNI, LocalDate fechaNombramiento) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.fechaNombramiento = fechaNombramiento;
    }

    // Getters y setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public LocalDate getFechaNombramiento() {
        return fechaNombramiento;
    }

    public void setFechaNombramiento(LocalDate fechaNombramiento) {
        this.fechaNombramiento = fechaNombramiento;
    }
}
