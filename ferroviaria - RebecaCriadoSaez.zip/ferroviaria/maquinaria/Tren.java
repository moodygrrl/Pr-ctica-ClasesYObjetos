package ferroviaria.maquinaria;

public class Tren {

    // Atributos

    // locomotora

    // máx 5 vagones

    // maquinista responsable del tren

    // en esta clase el constructor parametrizado solo lleva locomotora

    /* método añadirVagón():void
       que mira los vagones que tiene el tren y si es 5 indicamos que no se puede añadir ningún vagón más


       si tiene menos de 5:
        • carga máxima y tipo de mercancía se piden por teclado
        • los vagones se crean con una carga actual igual a 0
        • en cuanto al identificador, a cada vagón que se crea se le asigna un identificador que es: el número de trenes creados hasta el momento, más el número de vagones que tenga el tren actualmente.

     */

     // Por último, este método añade el vagón creado al tren.


    // método que elimina el último vagón del tren.

    // Modifica en la clase tren el método getVagones() para que devuelva el número de vagones que componen el tren.




}
