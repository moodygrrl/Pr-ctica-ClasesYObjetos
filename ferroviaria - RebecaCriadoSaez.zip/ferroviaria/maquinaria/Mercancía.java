package ferroviaria.maquinaria;

enum Mercancía {
    PERECEDERA, NO_PERECEDERA, FRÁGIL, PELIGROSA, DIMENSIONAL
}

