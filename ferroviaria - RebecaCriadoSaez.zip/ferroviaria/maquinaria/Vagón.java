package ferroviaria.maquinaria;

class Vagón {

    // Atributos
    protected String id;
    protected int cargaMáxima;
    protected int cargaActual;
    Mercancía mercancía;

    // Constructor
    public Vagón(String id, int cargaMáxima, int cargaActual, Mercancía mercancía) {
        this.id = id;
        this.cargaMáxima = cargaMáxima;
        this.cargaActual = cargaActual;
        this.mercancía = mercancía;
    }

    // Getters y setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getCargaMáxima() {
        return cargaMáxima;
    }

    public void setCargaMáxima(int cargaMáxima) {
        this.cargaMáxima = cargaMáxima;
    }

    public int getCargaActual() {
        return cargaActual;
    }

    public void setCargaActual(int cargaActual) {
        this.cargaActual = cargaActual;
    }
}
