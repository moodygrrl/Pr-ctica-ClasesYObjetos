package ferroviaria.maquinaria;

import ferroviaria.personal.Mecánico;

import java.time.LocalDate;

public class Locomotora {

    // Atributos
    String matrícula;
    int potencia;
    LocalDate añoFabricación;
    //Mecánico mecánico = new Mecánico();

    // Constructor
    public Locomotora(String matrícula, int potencia, LocalDate añoFabricación) {
        this.matrícula = matrícula;
        this.potencia = potencia;
        this.añoFabricación = añoFabricación;
    }

    // Getters y setters
    public String getMatrícula() {
        return matrícula;
    }

    public void setMatrícula(String matrícula) {
        this.matrícula = matrícula;
    }

    public int getPotencia() {
        return potencia;
    }

    public void setPotencia(int potencia) {
        this.potencia = potencia;
    }

    public LocalDate getAñoFabricación() {
        return añoFabricación;
    }

    public void setAñoFabricación(LocalDate añoFabricación) {
        this.añoFabricación = añoFabricación;
    }
}
